
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('data/sales_data.csv')

print(df.head())
print(df.describe())

category_sales = df.groupby('Category')['Sales'].sum()
print(category_sales)

category_sales.plot(kind='bar')
plt.title('Sales by Category')
plt.tight_layout()
plt.savefig('images/sales_by_category.png')
plt.show()
